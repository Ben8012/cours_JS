// Exo2 - Portrait ou vertical
// Ecrire une fonction "isLandscape" qui prendra en paramètre la longueur et la largeur
// et retournera si elle est bien en horizontale (landscape)
//
// exemple: isLandscape(1024, 520) //true
//          isLandscape(520, 1024) //false