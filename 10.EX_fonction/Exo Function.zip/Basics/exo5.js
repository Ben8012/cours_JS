// Exo5 - Nombre premier
// Ecrire une fonction "showNumbers" qui prendra en paramètre un nombre correspondant à une limite. (Cette limite sera la fin de la boucle)
// Elle affichera si l'itération de la boucle est un nombre pair ou impaire
// Exemple
// showNumbers(2)
// 0 "PAIRE"
// 1 "IMPAIRE"
// 2 "PAIRE"