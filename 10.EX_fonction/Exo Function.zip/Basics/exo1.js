// Exo 1 - Plus grand nombre
// Ecrire une fonction "max" qui prendra en paramètres deux nombres
// et retournera le plus grand des deux
//
// exemple => max(1, 2) // 2