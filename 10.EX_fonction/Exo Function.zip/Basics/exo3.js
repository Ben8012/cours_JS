// Exo3 - FizzBuzz Algorithm
// Ecrire une fonction "fizzBuzz" qui prendra en paramètre un nombre
// Résulat attendu
// Si le nombre est divisible par 3 => Affichez "Fizz"
// Si le nombre est divisible par 5 => Affichez "Buzz"
// Si le nombre est divisible par 3 et 5 => Affichez "FizzBuzz"
// Si le nombre n'est pas divisble par 3 ou 5 => Affichez le nombre entré en paramètre
// Si le nombre n'est pas un nombre => Affichez "Not a number"