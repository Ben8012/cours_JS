// Exo4 - Limite de vitesse
// Ecrire une fonction "checkSpeed" qui prendra en paramètre un nombre correspondant à la vitesse du conducteur
// La limite de vitesse sera de 70
// A chaque 5km au dessus de la limite le conducteur perdra 1 point, arrivez à 12 son permis sera suspendu
// Indice : utilisation de Math.floor.
// NE PAS UTILISER DE BOUCLE
// Résulat attendu
// checkSpeed(70) // OK
// checkSpeed(72) // OK
// checkSpeed(75) // Point : 1
// checkSpeed(80) // Point : 2
// checkSpeed(180) // Permis Suspendu