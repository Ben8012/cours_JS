// Séléction de mes élément
const productsList = document.getElementById('products');
const cartList = document.getElementById('cart');
const totalElement = document.getElementById('total');

// Produits
const products = [
    {
        name: 'Chaise',
        unitPrice: 25.50
    },
    {
        name: 'TV',
        unitPrice: 100.25
    },
    {
        name: 'Meuble',
        unitPrice: 75.10
    }
];
// Contenir les produits du panier
// { name, unitPrice, qty}
const productsCart = [];

updatePrice();

// Affichage de la liste des produits
for (const product of products) {
    const productItem = document.createElement('li');
    productItem.innerHTML = `${product.name} - ${product.unitPrice}€`;
    const addBtn = document.createElement('button');
    addBtn.innerHTML = 'Ajouter au panier';
    addBtn.addEventListener('click', () => {
        // Trouver le produit dans le tableau
        const cartProduct = productsCart.find((p) => {
            return p.name === product.name;
        });
        if (!cartProduct) {
            // Ajouter le produit dans le panier
            productsCart.push({...product, qty: 1});
        }else {
            cartProduct.qty += 1;
        }
        updateCart();
        updatePrice();
    })

    productItem.appendChild(addBtn);
    productsList.appendChild(productItem);
}
// Affihage Panier
function updateCart() {
    updatePrice();
    // Supprimer le contenu d'une balise
    deleteChildren(cartList);

    for (const productCart of productsCart) {
        const productItem = document.createElement('li');
        productItem.innerHTML = `${productCart.name} - ${productCart.unitPrice}€ - x ${productCart.qty}`;
        // Add Button
        const addBtn = document.createElement('button');
        addBtn.innerHTML = '+';
        addBtn.addEventListener('click', () => {
            productCart.qty += 1;
            updateCart();
        })
        // remove Button
        const removeBtn = document.createElement('button');
        removeBtn.innerHTML = '-';
        removeBtn.addEventListener('click', () => {
            if (productCart.qty === 1) {
                const productCartIndex = productsCart.findIndex((p) => {
                    return p.name = productCart.name
                });
                productsCart.splice(productCartIndex, 1);
            } else {
                productCart.qty -= 1;
            }
            updateCart();
        })

        productItem.appendChild(addBtn);
        productItem.appendChild(removeBtn);

        cartList.appendChild(productItem);
    }
}

function deleteChildren(parent) {
    while (parent.firstChild) {
        parent.removeChild(parent.firstChild);
    }
}

function calcPriceCart() {
    const total = productsCart.reduce((acc, product) => {
        return acc + (product.qty * product.unitPrice);
    }, 0);
    return total;
}

function updatePrice() {
    totalElement.innerHTML = `Total: ${calcPriceCart()} €`
}

// products.forEach((product) => {
//     const productItem = document.createElement('li');
//     productItem.innerHTML = `${product.name} - 
//     ${product.unitPrice.toLocaleString('fr-BE', 
//         {
//             style: 'currency', 
//             currency: 'EUR', 
//             minimumFractionDigits: 2
//         }
//     )}`;
//     const addBtn = document.createElement('button');
//     addBtn.innerHTML = 'Ajouter au panier';
//     // Ajout de l'événement ajout produit
//     addBtn.addEventListener('click', () => {
//         const cartProduct = document.createElement('li');
//         cartProduct.innerHTML = `${product.name} - 
//             ${product.unitPrice.toLocaleString('fr-BE', 
//                 {
//                     style: 'currency', 
//                     currency: 'EUR', 
//                     minimumFractionDigits: 2
//                 }
//             )}`;
//         cartList.appendChild(cartProduct);
//         // Calcul du total
//         total += product.unitPrice; // total = total + product.unitPrice
//         totalElement.innerHTML = `Total: ${total.toLocaleString('fr-BE', 
//             {
//                 style: 'currency', 
//                 currency: 'EUR', 
//                 minimumFractionDigits: 2
//             }
//         )}`
//     });
//     productItem.appendChild(addBtn)
//     productsList.appendChild(productItem);
// })
